--------------------------------------------------------------------------------
IndexOutOfRange csapat
Carcassonne játék v1.0
--------------------------------------------------------------------------------

Köszönjük, hogy kipróbálja a mi játékunkat!

================================================================================

1.0. Rendszerkövetelmények

FONTOS! Ez a termék Visual Studio 2022-ben íródott, tehát a maximális élmény érdekében kérem használja azt.
	Kérjük biztosítsa, hogy a lehető legfrissebb verziójú a program.

1.0.1 Minimum Konfiguráció: 

  Operációs rendszer: Windows 7 32 bit, Windows 8 32 bit, Windows 10 32 bit. 
 
  Processzor:         Intel Core i3 560 @ 3.3GHz or better,
                      AMD Phenom II X4 945 @ 3.0Ghz or better
 
  RAM:                4 GB
  
  Videokártya:        NVIDIA GeForce GTX 460, AMD Radeon HD 5870 
                      És DX11-et használó kártyák legalább 1GB memóriával

  Szükséges tárhely:  280 MB
  
  Hang:               DirectX 9.0c-vel kompatibilis hangkártya, a legújabb illesztőprogrammal

Windowssal kompatibilis egér szükséges

================================================================================

2.0. Program Futtatása

2.0.1 Visual Studio 2022 Telepítése

-Nyissa meg a következő weboldalt egy böngészőben: https://visualstudio.microsoft.com/vs/
-Vigye a "Download" gombra az egeret, majd kattintson a Community 2022 gombra.
-Nyissa meg a telepítő programot, majd kövesse az utasításokat.

2.0.2 A Futtatás Lépései

-Nyissa meg a Visual Studio 2022-t
-A programon belül nyissa meg a Carcassonne.sln fájlt (Ha először futtatja a játékot, akkor ez eltarthat egy-két percig).
-Nyomja le a Ctrl+F5 billentyűkombinációt a játék futtatásához.
-Élvezze a játékot

================================================================================
3.0. Fontos Webhelyek

A webhelyek a "Website" mappában találhatók.