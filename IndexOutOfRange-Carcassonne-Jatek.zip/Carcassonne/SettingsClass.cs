﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carcassonne
{
    class SettingsClass
    {

        bool enableMusic = true;
        bool enableSoundEffects = true;
        bool timeMode = false;

    }
}
