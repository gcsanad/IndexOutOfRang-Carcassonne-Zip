--------------------------------------------------------------------------------
Team IndexOutOfRange
Carcassonne game v1.0
--------------------------------------------------------------------------------

Thank you, for trying out our game!

================================================================================

1.0. System Requirements

IMPORTANT! This product was written in Visual Studio 2022, so please use it for the best experience.
	   Please ensure that the program has the latest version.

1.0.1 Minimum cConfiguration:

  Operating System: Windows 7 32 bit, Windows 8 32 bit, Windows 10 32 bit. 
 
  Processor:        Intel Core i3 560 @ 3.3GHz or better,
                    AMD Phenom II X4 945 @ 3.0Ghz or better
 
  RAM:              4 GB
  
  Video card:       NVIDIA GeForce GTX 460, AMD Radeon HD 5870 
                    And DX11 cards with 1GB VRAM
  
  Storage space:    280 MB
  
  Sound:            DirectX 9.0c Compatible Sound Card with Latest Drivers

  Windows-compatible mouse required

================================================================================

2.0. Running The Program

2.0.1 Installing Visual Studio 2022

-Open the following web page in a browser: https://visualstudio.microsoft.com/vs/
-Move your cursor over the "Download" button and click the Community 2022 button.
-Open the installer and follow the instructions.

2.0.2 The steps for running the program

-Open Visual Studio 2022
-Open the Carcassonne.sln file inside the program (If it is your first time running the program, then it could take 1-2 minutes).
-Press Ctrl+F5 to run the game.
-Enjoy playing the game

================================================================================
3.0. Important Websites

The websites are located in the "Website" folder.